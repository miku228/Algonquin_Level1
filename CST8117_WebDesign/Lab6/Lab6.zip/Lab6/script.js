// global variables
var operator = ""
var operators = ["+", "-", "/", "X"]
var disStr = ""
let calculateCount = 0
var el = document.getElementById("result")

// When click "C", clear(set 0) to the results
function clearDis() {
    operator = "";
    disStr = "";
    calculateCount = 0
    el.innerHTML = "0";
}

// concat the input(num&operators) and show in the results
function concatDis(val) {
    if(el.innerHTML == "0") {
        el.innerHTML = val;
    } else {
        el.innerHTML +=  val
    }
}

// when click operators set curent operator or calculate
function setOperator(op) {
    if(operator != "") {
        // need to calculate
        calculateDis()
    }
    // set the operator
    switch(op) {
        case "+":
            operator = "+"
            break;
        case "-":
            operator = "-"
            break;
        case "/":
            operator = "/"
            break;
        case "X":
            operator = "X"
            break;
    }

    // set the disStr for calculate
    disStr += op

}

// When click numbers, show to the result
function display(value) {

    let lastInp = disStr.substring(disStr.length-1);
    if(calculateCount>0 && operators.includes(lastInp)) disStr = el.innerHTML + operator;
    // if last input is operator, show click number to the result
    if(operators.includes(lastInp)){
        el.innerHTML = value
        
    }else{
    // concat button values and display
        concatDis(value)
    }

    disStr += value
}


function calculateDis() {
    calculateCount += 1;
    let operands = disStr.split(operator);
    let result = 0;
    
    for(i in operands) {
        if(i == 0) {
            result = parseFloat(operands[i])
        }else{
            switch(operator) {
                case "+":
                    result += parseFloat(operands[i])
                    break
                case "-":
                    result -= parseFloat(operands[i])
                    break;
                case "/":
                    result = result / parseFloat(operands[i])
                    break;
                case "X":
                    result = result * parseFloat(operands[i])
                    break;
            }
        }

    }

    el.innerHTML = String(result);

    // reset the operator
    operator = ""
}