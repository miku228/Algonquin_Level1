1. ex01.py
       import cmath module to use them in this script.
       set int values to three valiable a,b,c(statement)
       set int value which is calcurated from three values to valiable d(expression)
       set values which is calcurated by using cmath.squrt function(expression).
       then finally print it out using format method.

2. ex02.py
       using input method ask to user to put in number, then format it to float type. it assign to variable(kilometers)
       set variable conv_fanc, which comes to float type automatically.
       then print results using print method. %0.2f and %() means format the values to two digit after decimal.

3. ex03.py
       Set variable year(statement).
       In If condition statement, it check the boolean value. If it's true it goew inside, it's not skip inside then go to next line which is in else statement.
       First if statement (year%4 == 0) comes true,then go to line9. second if statement also true, then go to line10. Third if statement also is true, then move to line11.
       In line 11 using print method the values are printed.
